
##############################################################################
# EVOLIFE											  Jean-Louis Dessalles  #
#			Telecom ParisTech  2011					   www.enst.fr/~jld  #
##############################################################################


##############################################################################
#  Retrieving average values from result files							   #
##############################################################################

""" EVOLIFE: Retrieving average values from result files
"""


import sys
import os.path
import glob
import re
import random
import zipfile
from collections import OrderedDict
import numpy as np

tostr = lambda S: S.decode('utf-8') if type(S) == bytes else S

Experiences = dict()	# each element is a list of experiences with same parameters
Variables = []

def openFile(FileName, ZipContainer=None):
	if ZipContainer is not None:
		return ZipContainer.open(FileName,'r')
	else:
		return open(FileName,'rb')

def getResult(FileName, ZipContainer=None, NroLine=-1, Header_ref=None, Numeric=True):
	""" retrieves the last line of a resut file, checks that it only contains
		numbers, and returns it
	"""
	global Variables
	print(FileName)
	LL = openFile(FileName, ZipContainer).read().splitlines()
	for delimiter in [';', ',']:
		Header = tostr(LL[0]).split(delimiter)
		if len(Header) > 1:	
			ActualDelimiter = delimiter
			break
	ContentLine = tostr(LL[NroLine]).split(delimiter)
	if Numeric:
		# ------ checking that there are only numeric values
		# NumberList = re.split("\s+", LL.strip())
		Test = [int(N) for N in ContentLine]
	ContentDict = OrderedDict(zip(Header, ContentLine))
	if Header_ref is not None:
			Fields = Header_ref.split(delimiter)
	else:	Fields = ContentDict.keys()
	# Patch: removing lists (e.g. LevelBase)
	for F in Fields[:]:
		if F in ContentDict:
			if ContentDict[F].startswith('['): Fields.remove(F)
			if ContentDict[F].startswith('('): Fields.remove(F)
		else:
			raise Exception(f"Error: incorrect header in {FileName} - {F} missing")
	# ====== storing experiences with same parameter values
	# print(''.join(FileName.split('_res'))
	Variables = openFile(''.join(FileName.split('_res')), ZipContainer).readline().decode('utf-8').strip().split(ActualDelimiter)
	# print(Variables)
	ExperienceKey = ';'.join([ContentDict[F] for F in Fields if F in ContentDict and F not in ['Date'] + Variables])
	if ExperienceKey in Experiences:	Experiences[ExperienceKey].append(FileName)
	else:	Experiences[ExperienceKey] = [FileName]
	return (';'.join(Fields), ';'.join([ContentDict[F] for F in Fields if F in ContentDict]))

def saveResults(Results, Header, OutputFileName):
	"   appends lines to a global result file "
	F = open(OutputFileName, 'a')
	F.write(Header + '\n')
	for R in Results:	F.write(R + '\n')
	F.close()
	
def getAverage(Config, Header, ExpeList, ZipContainer=None):
	"""	Averages experiences from dump files
	"""
	global Variables
	Averages = dict()	# for each feature -> an array
	for Expe in ExpeList:
		DumpFileName = Expe.split('_res')[0] + '_dmp.csv'
		Lines = openFile(DumpFileName, ZipContainer).read().decode('utf-8').split('\n')
		for L in Lines[1:]:
			if L.strip() == '':	continue
			feature, array = tuple(L.split(';', maxsplit=1))
			array = np.fromstring(array, dtype=float, sep=';')
			if feature in Averages:
				Averages[feature] += array
			else:
				Averages[feature] = array
	for feature in Averages:
		Averages[feature] /= len(ExpeList)
	# print(f'Average for {Lines[0]}: \n{Averages}')
	# ====== saving averages
	Header = ';'.join([h for h in Header.split(';') if h not in Variables])
	Avg = open(ExpeList[0].split('_res')[0] + '_avg.csv', 'w')
	Avg.write(Header + '\n')
	Avg.write(Lines[0].strip() + ';')
	Avg.write(Config + '\n')
	for feature in Averages:
		Avg.write(feature + ';')
		Avg.write(np.array2string(Averages[feature], precision=2, formatter={'float_kind':lambda x: "%.2f" % x}, separator=';').strip('[]').replace('\n', '').replace(' ', '') + '\n')
	Avg.close()
	return Averages
			

	
if __name__ == "__main__":
	##	print __doc__ + '\n'
	if len(sys.argv) < 3:
		print('usage:')
		print('%s <file1_res.csv ... fileN_res.csv | file*.res | Results.zip> <outputfile.csv>' % os.path.basename(sys.argv[0]))
		print("The last line of each file_res.csv is appended to <outputfile.res> ")
		sys.exit()
	ZipContainer = None
	if len(sys.argv) == 3:
		if sys.argv[1].find('*') >= 0:
			Args = glob.glob(sys.argv[1])
		elif sys.argv[1].endswith('.zip'):
			ZipContainer = zipfile.ZipFile(sys.argv[1])
			Args = [f for f in ZipContainer.namelist() if f.endswith('_res.csv')]
	else:	Args = sys.argv[1:-1]
	OutputFileName = sys.argv[-1]
	# Tinkering to get true header even when some csv file headers are incomplete
	Sample = random.sample(Args, min(50, len(Args)))
	Header = ''
	Witness = None
	for F in Sample:
		Header1 = openFile(F, ZipContainer).readline().strip()	# will be used as reference
		if len(Header1) > len(Header):	
			Header = tostr(Header1)
			Witness = F
	print(Header)
	print("Appending those results to %s" % OutputFileName)
	Results = []
	Fields = getResult(Witness, ZipContainer=ZipContainer, NroLine=1, Header_ref=Header, Numeric=False)[0]
	for A in Args:
		try:	Results.append(getResult(A, ZipContainer=ZipContainer, NroLine=1, Header_ref=Header, Numeric=False)[1])
		except Exception as Msg:	print(Msg)
	saveResults(Results, Fields, OutputFileName)
	# saving Experiences
	if ZipContainer is None:
		print()
		for E in Experiences: 
			print(E)
			print('\n'.join(Experiences[E]))
			Avg = getAverage(E, Header, Experiences[E], ZipContainer=ZipContainer)
			# print(Avg['Signal'])
			# print(len(Avg['Signal']))
			print()
	print ('%d files processed' % len(Args))
	print(f'Result on {OutputFileName}')

