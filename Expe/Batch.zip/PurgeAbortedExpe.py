##############################################################################
# EVOLIFE  www.dessalles.fr/Evolife                    Jean-Louis Dessalles  #
#            Telecom Paris  2022                           www.dessalles.fr  #
##############################################################################


"""	Suppresses aborted experience from the output of Get_Results
"""
import sys
import TableDBM as T
import TableCsv as TCsv


if __name__ == "__main__":
	# Delimiter = ','
	Delimiter = ';'
	Dialect = TCsv.Dialect(delimiter=Delimiter, quotechar='"', fullQuote=False)
	Results = T.DBaseDisk(sys.argv[1], csvDialect=Dialect)
	print(len(Results), 'experiences found')
	# print(Results.FieldNames)
	Lasts = Results.column('LastStep')
	histo = {x:Lasts.count(x) for x in Lasts}
	NormalLast = max(histo.items(), key=lambda x: x[1])[0]
	Results1 = Results.get_records([('equal', 'LastStep', NormalLast)])
	print(len(Results1), 'experiences kept')
	# T.DBaseDisk(FileName=sys.argv[2], relation=Results1).save(format='oldcsv')
	# T.DBaseDisk(FileName=Results.FileName, relation=Results1).save(format='oldcsv')
	T.DBaseDisk(FileName=Results.FileName, relation=Results1).save(csvDialect=Dialect)
	
