#echo usage: sh go.sh <Typical_xxx.evo> <fich.evm> <python program>
#echo or
#echo usage: sh go.sh <program and config name (no ext)>
echo lancement d une experience
cd ~/Evolife/Apps/Patriot
nohup nice sh ./Explore.sh $1.evo $1.evm ___$1.evo $1.py &
