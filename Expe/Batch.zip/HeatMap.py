
# after https://matplotlib.org/stable/gallery/images_contours_and_fields/pcolor_demo.html

import sys
import os
import matplotlib.pyplot as plt
import numpy as np

DPI = 300	# definition of saved images

def get2Ddata(FileName):
	"""	Read csv file containing 2D data as a table
	"""
	Lines = open(FileName).readlines()
	# First line contains variable names + config
	ytitle, xtitle, ztitle = Lines[0].split(';')[3:6]
	x = np.array(list(map(float, Lines[1].split(';')[1:]))) 	# Line 1 contains x-values
	y = []	# y-values
	z = []
	for line in Lines[2:]:
		line = line.split(';')
		y.append(float(line[0]))
		z.append(list(map(float, line[1:])))
	y = np.array(y)
	z = np.array(z)
	print(x)
	print(y)
	print(z)
	return xtitle, x, ytitle, y, ztitle, z
		
		
	

if __name__ == "__main__":
	Data2D = sys.argv[1]
	xtitle, x, ytitle, y, ztitle, z = get2Ddata(Data2D)
	'''
	# generate 2 2d grids for the x & y bounds
	y, x = np.meshgrid(np.linspace(-3, 3, 200), np.linspace(-3, 3, 200))

	z = (1 - x / 2. + x ** 5 + y ** 3) * np.exp(-x ** 2 - y ** 2)
	# x and y are bounds, so z should be the value *inside* those bounds.
	# Therefore, remove the last value from the z array.
	z = z[:-1, :-1]
	'''
	z_min, z_max = 0, np.abs(z).max()
	# z_min, z_max = 0, 100

	fig, ax = plt.subplots()

	c = ax.pcolormesh(x, y, z, cmap='Blues', shading='nearest', vmin=z_min, vmax=z_max)
	ax.set_title(ztitle)
	ax.set_xlabel(xtitle)
	ax.set_ylabel(ytitle)
	# set the limits of the plot to the limits of the data
	ax.axis([x.min(), x.max(), y.min(), y.max()])
	fig.colorbar(c, ax=ax)

	ImageName = f'_{xtitle}_x_{ytitle}.png'
	plt.show()
	fig.savefig(ImageName, dpi=DPI)

