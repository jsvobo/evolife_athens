
""" reconstructs Evogen.dat from a set of _res.csv files
"""

from glob import glob

PARAMS = ('ContemptImpact', 'FollowerImpact')
ResFile = 'EvoGen.dat'

def get_param_values(FileName):
	L = open(FileName).readlines()
	paramList = L[0].strip().split(';')
	values = L[1].strip().split(';')
	return tuple(values[ paramList.index(p) ] for p in PARAMS)

if __name__ == "__main__":
	Files = glob('*_res.csv')
	param_values = dict()
	for F in Files:
		pv = get_param_values(F)
		if pv in param_values:
			param_values[pv] += 1
		else:
			param_values[pv] = 1
	# print(param_values)
	R = open(ResFile, 'w')
	for p,v in param_values:
		R.write(f'{PARAMS[0]}\t{PARAMS[1]}\t{p}\t{v}\t{param_values[(p,v)]}\n')
	R.close()
	print(len(param_values), 'explored')
	
