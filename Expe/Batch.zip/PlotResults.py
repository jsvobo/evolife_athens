
##############################################################################
# EVOLIFE  www.dessalles.fr/Evolife                    Jean-Louis Dessalles  #
#            Telecom ParisTech  2016                       www.dessalles.fr  #
##############################################################################

##############################################################################
# Draw curves offline using matplotlib                                       #
##############################################################################

""" Draw curves offline.
	Takes a csv file as input and draws curves.
	Creates image file.
"""


import sys
import os
import csv
import re
import matplotlib
matplotlib.use('Agg')	# to use offline
import matplotlib.pyplot as plt

DPI = 300	# definition of saved images
LEGENDPOSITION = 'upper right'
# LEGENDPOSITION = 'lower right'
# LEGENDPOSITION = 'lower left'
# LEGENDPOSITION = 'right'
# LEGENDPOSITION = 'best'
# LEGENDPOSITION = 'upper left'

# Parameter_rename = {'PolicingProbability': 'Praising Probability'}
Parameter_rename = {
				'Cutoff': 'Cut-off',
				'VisibilityGossip': 'Visibility due to praising',
				'PraisingProbabilitySignallers': 'Praising probability of signalers',
				'SignalLevel2': 'Social signal ($S_2$)',
				'SignalLevel3': 'Top signal ($S_H$)',
				"TopSignallers": "Prop. of top signalers ($\\times 10$)",
				"NbAgents": "Number of agents ($N$)",
				'PropSuicides':	'# suicides per year (per thousand)',
				'Risk':	'Probability of committing suicide',
				# 'Risk':	'Probability of committing suicide x 10',
				}

RePaint = {
		'PraisingProbability':	'orange',
		'PraisingProbabilitySignallers':	'orange',
		'SignalLevel1':			'lightblue',
		'SignalLevel2':			'#4444FF',
		# 'SignalLevel3':			'darkblue',
		'SignalLevel3':			'green',
		'Cutoff':				'red',
		'TopSignallers':		'lightgreen',
		'Risk':					'blue',
		'PropSuicides':			'red',
		'LifeExpectancy':		'yellow',
		}

def parameterName(P):
	if P in Parameter_rename:	
		print(f'Renaming {P} as {Parameter_rename[P]}')
		return Parameter_rename[P]
	return re.sub('([A-Z])', ' \g<1>', P).strip()

def str2nb(x):	
	try: return int(x)
	except ValueError:	return float(x)

if __name__ == "__main__":
	datafilename = sys.argv[1]
	# parameter = datafilename.split('_')[1]
	# colours = ['#0000BF', '#BF7000', '#78FF78', '#FF7878', '#0000BF', '#7878FF', '#F54374', '#54F254', '#2383F3']
	colours = ['#0000BF', '#EB7A00', '#60D060', '#FF7878', '#0000BF', '#7878FF', '#F54374', '#54F254', '#2383F3']
	R = csv.reader(open(datafilename), delimiter=';')
	# next(R)	# skipping configuration line
	ColumnNames = next(R)
	Legend = list(map(parameterName, ColumnNames))
	Offset = 1 if Legend[0] == 'Date' else 0
	parameter = Legend[0]
	# R = sorted(list(R), key=lambda x: x[Offset])
	Columns = list(zip(*R))
	Columns = list(map(lambda L: list(map(str2nb, L)), Columns))
	# for Col in range(1,len(Columns) - Offset):
	for Col in range(len(Columns) - Offset-1, 0, -1):
		Curve = ColumnNames[Col+Offset]
		if Curve == 'Cutoff':	continue
		elif Curve == 'SignalLevel1':	continue
		elif Curve == 'PraisingProbabilitySignallers':	continue
		# elif Curve in ['Risk', 'PropSuicides']:	
		elif Curve in ['xxxxxxxx']:	
			Columns[Col+Offset] = list(map(lambda x: x*10, Columns[Col+Offset]))
		CurveName = Legend[Col+Offset]
		Color = colours[Col-1]
		if Curve in RePaint:	Color = RePaint[Curve]
		plt.plot(Columns[Offset], Columns[Col+Offset], linewidth=3, color=Color, label=CurveName)	
	x1,x2,y1,y2 = plt.axis()
	plt.axis((x1, x2, 0, y2+0.05))
	plt.grid(color='b', ls = '-.', lw = 0.25)
	plt.ylim(top=100)
	plt.xlabel(parameter)
	# plt.ylabel('price or sales')
	# plt.legend(bbox_to_anchor=(0.1, 1))
	plt.legend(loc=LEGENDPOSITION, fontsize=8)
	# plt.show()
	# saving image file
	expeName = os.path.splitext(datafilename)[0].split('_Histo')[0]
	imagefilename =  f'_{expeName}.png'
	if os.path.exists(imagefilename):	os.remove(imagefilename)
	plt.savefig(imagefilename, dpi=DPI)
	print("%s created" % imagefilename)	


__author__ = 'Dessalles'
