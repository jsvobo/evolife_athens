##############################################################################
# EVOLIFE  www.dessalles.fr/Evolife                    Jean-Louis Dessalles  #
#            Telecom ParisTech  2016                       www.dessalles.fr  #
##############################################################################


"""	Select experiences that are representative of the influence of a parameter
	and generates an animated gif.
"""


import sys
import os
import csv

TEMPSCRIPT = '___gifscript.txt'

def getProgramLocation(PgmName):
	" Utile pour trouver un programme qui differe selon les installations "
	if os.name == 'nt':	
		PgmLocs = ['c:/program files','c:/program files (x86)']
		for Loc in PgmLocs:
			for R in os.listdir(Loc):
				if R.lower().startswith(PgmName.lower()):
					return os.path.join(Loc, R)
	return PgmName

def str2nb(x):	
	try: return int(x)
	except ValueError:	return float(x)

if __name__ == "__main__":
	datafilename = sys.argv[1]
	# parameter = datafilename.split('_')[1]
	R = csv.reader(open(datafilename), delimiter=';')
	next(R)	# skipping configuration line
	Legend = next(R)
	parameter = Legend[1]
	experiences = {expe[1]:expe[0] for expe in R}
	experiences = sorted(experiences.values(), key = lambda x: x[0])
	expeName = os.path.splitext(datafilename)[0].split('_lines')[0]	# par ex. 'Patriot_SignallingCost'
	pgmName = expeName.split('_')[0]	# par ex. 'Patriot'
	script = open(TEMPSCRIPT, 'w')
	for expe in experiences:
		os.system(r'\recherch\Evolife\plotNew.py ' + f'{pgmName}_{expe}.csv {pgmName}.evo {parameter}_noField')
		script.write(f"file '{pgmName}_{expe}.png'\nduration 2\n")
	script.close()
	
	# os.system(f'ffmpeg -y -framerate 1 -i {TEMPSCRIPT} -c:v libx264 -pix_fmt yuv420p -r 30 {expeName}.mov')
	os.spawnl(os.P_WAIT, getProgramLocation('ffmpeg') + '/bin/ffmpeg.exe', f' -hide_banner -loglevel warning -y -f concat -i {TEMPSCRIPT} -c:v libx264 -pix_fmt yuv420p -r 30 {expeName}.mov')
	# os.system(f'ffmpeg -y -f concat -i {TEMPSCRIPT} -c:v libx264 -pix_fmt yuv420p -r 30 {expeName}.mov')
	os.spawnl(os.P_WAIT, getProgramLocation('ffmpeg') + '/bin/ffmpeg.exe', f' -hide_banner -loglevel warning -y -i {expeName}.mov -pix_fmt rgb24 -loop 0 _{expeName}.gif')
	
	print(f"_{expeName}.gif created")


__author__ = 'Dessalles'
