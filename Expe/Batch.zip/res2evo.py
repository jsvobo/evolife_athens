
""" reconstructs configuration file .evo from a  _res.csv file
"""

import sys
import os

def get_param_values(FileName):
	"""	retrieves parameter values from result _res.csv file
	"""
	# first retrieve variable names to then get rid of them
	CurveFile = FileName.split('_res.csv')[0] + '.csv'
	Variables = open(CurveFile).readline().strip().split(';')
	Variables += ['Date', 'LastStep']
	L = open(FileName).readlines()
	paramList = L[0].strip().split(';')
	values = L[1].strip().split(';')
	param_values = zip(paramList, values)
	return tuple(pv for pv in param_values if pv[0] not in Variables)

def usage(cmd):
	print(f'''
Usage: {cmd} <expe>_res.csv
Generates <expe>.evo if that files does not exist
	''')
	
if __name__ == "__main__":
	Filin = sys.argv[-1]
	if not Filin.endswith('_res.csv'):
		usage(os.path.basename(sys.argv[0]))
		sys.exit(1)

	pv = get_param_values(Filin)

	Filout = f'{Filin.split("_res.csv")[0]}.evo'
	if os.path.exists(Filout):
		print(f'File {Filout} already exists!')
	else:
		R = open(Filout, 'w')
		R.write('ParamName\tParamValue\n')
		for p,v in pv:
			R.write(f'{p}\t{v}\n')
		R.close()
		print(len(pv), 'parameters found')
		print(f'{Filout} created')
			
