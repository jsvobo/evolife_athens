##############################################################################
# EVOLIFE											  Jean-Louis Dessalles  #
#			Telecom ParisTech  2011					   www.enst.fr/~jld  #
##############################################################################


##############################################################################
#  EVOLIFE: Automatic manipulation of Evolife configuration files.		   #
##############################################################################

""" EVOLIFE: Automatic manipulation of Evolife configuration files.
	Parameter values are replaced by randomly selecting actual values
	from a range of values mentioned in a 'meta-configuration-file'
	Useful to generate series of experiences automatically
"""

if __name__ == "__main__":
	# Putting Evolife into the path (supposing we are in the same directory tree)
	import sys, os
	for R in os.walk(os.path.abspath('.')[0:os.path.abspath('.').find('Evo')]):
		if os.path.exists(os.path.join(R[0],'Evolife','__init__.py')):
			sys.path.append(R[0])
			break


import sys
import os
import random 
import re
import copy
import itertools
from time import time, sleep
import shutil
import glob

# sys.path.append('..')
from Evolife.Tools.Tools import error
from Evolife.Scenarii.Parameters import Parameters, Num

#########################################
# Loading global parameters			 #
#########################################


AlreadyExploredValuesFileName = "EvoGen.dat"
AlreadyExploredValuesFileNameBis = "___EvoGen.dat"
STOPFILE = 'fini'
WAITINGTIMEOUT = random.randint(3, 31)

class MetaParameters(Parameters):
	""" class MetaParameters: Parameter values and Parameter ranges
	"""

	def __init__(self, ConfigFile, MetaConfigFile, Multiplicative=False):
		Parameters.__init__(self, ConfigFile)
		self.Original = copy.deepcopy(self.Params)	 # saving the original values
		self.RangeParamWithStep = []
		self.ListParam = []
		self.FixedParam = []
		self.txt_to_ValueRange(MetaConfigFile)
		self.Ranges = self.Get_Ranges()
		self.NoRanges = dict(self.FixedParam)
		self.MetaParams = list(self.Ranges.keys()) + list(self.NoRanges.keys())
		
		# checking that metaparameters are parameters
		for PP in self.Ranges:
			if not PP in self.Original:
				print("**************************************")
				print("Warning: unknown metaparameter:", PP)
				print("**************************************")
		for PP in self.NoRanges:
			if not PP in self.Original:
				print("******************* Warning: unknown metaparameter:", PP)
			
		self.Multiplicative = Multiplicative
##		print self.FixedParam
		self.ExploredSingle = dict()
		self.ExploredCouple = dict()
		try:
			self.ExploredValues(AlreadyExploredValuesFileName)   # gets already explored values
		except IOError:
			raise Exception(f'Cannot open {AlreadyExploredValuesFileName}')
		# checking that explored values are metaparameters 
		for MP in list(self.ExploredSingle.keys()):	#	copy keys
			if MP[0] not in self.MetaParams:
				print("Warning: Explored parameter not metaparameter:", MP[0])
				del self.ExploredSingle[MP]
		for (MP1,MP2) in list(self.ExploredCouple.keys()):	# copy keys
			if MP1[0] not in self.MetaParams:
				print("Warning: Explored parameter not Metaparameter:", MP1[0])
				del self.ExploredCouple[(MP1,MP2)]
			elif MP1[1] not in self.MetaParams:
				print("Warning: explored parameter not metaparameter:", MP1[1])
				del self.ExploredCouple[(MP1,MP2)]


	def txt_to_ValueRange(self, MetaConfigFile):
		""" Retrieves parameter range
			Either: <ParamName> <valmin>-<valmax> [<step>]
			or:	 <ParamName> <val1> <val2> ...
		"""
		CfgTxtStr = safeRead(MetaConfigFile)
		if CfgTxtStr is not None:
			self.RangeParamWithStep = re.findall(r"""   # e.g.: GSize  10-20 2 (to mean range(10,21,2)) 
				^(\w+)\s+   # parameter name
				(-?\d+--?\d+)\s+   # integer range:  10-20
				(-?\d+)*   # optional step
				""",CfgTxtStr, flags=re.MULTILINE|re.VERBOSE)
			self.ListParam = re.findall(r"""  # e.g.:  GSize  10 12 14 16
				^(\w+)\s+   # parameter name
				((?:-?[\d\.]+\s+)+   # sequence of values (note the non-capturing sub-group)
				(?:-?[\d\.]+))\s*$   # terminating value
				""",CfgTxtStr, flags=re.MULTILINE|re.VERBOSE)
			self.FixedParam = re.findall(r"""  # e.g.:  DisplayPeriod  10
				^(\w+)\s+   # parameter name
				(-?[\d\.]+)\s*$   # terminating value
				""",CfgTxtStr, flags=re.MULTILINE|re.VERBOSE)
		else:
			raise Exception(f"Evolife Evogen: Problem accessing or interpreting metaconfiguration file {CfgTxtFile}")
		
	def Range_to_List(self, ParamRange):
		""" Converts a range of values into actual values: '10-20 4' --> [10,14,18]
			Keeps the list if no range
		"""
		PR = re.findall(r"(-?\d+)-(-?\d+)",ParamRange[1])
		if PR != []:
			if ParamRange[2] != '':
				Step = int(ParamRange[2])
			else:
				Step = 1
			return (ParamRange[0], list(range(int(PR[0][0]),int(PR[0][1])+1,Step)))
		# no range case:
		# return (ParamRange[0], [int(P) for P in re.split("[\-\D]+",ParamRange[1]) if P != ''])
		return (ParamRange[0], [Num(P) for P in ParamRange[1].split()])
		
	def Get_Ranges(self):
		Ranges = dict()
		for PR in self.RangeParamWithStep + self.ListParam:
			Param, RangeAsList = self.Range_to_List(PR)
			if Param not in Ranges:	Ranges[Param] = []
			Ranges[Param] += RangeAsList
		# return dict([self.Range_to_List(PR) for PR in self.RangeParamWithStep]
					# + [self.Range_to_List(PR) for PR in self.ListParam]
					# )
		for Param in Ranges:	Ranges[Param] = sorted(list(set(Ranges[Param])))
		return Ranges
			
	def Possibilities(self):
		" computes the total number of parameter configurations "
		Configurations = 0
		for R in self.Ranges:
			L = len(self.Ranges[R])
			if self.Multiplicative and Configurations:	Configurations *= L
			else:	Configurations += L
		return Configurations

	def ExploredValues(self, ExploredFileName, Store=False):
		" Retrieves or stores already explored values "
		if Store and (self.ExploredSingle or self.ExploredCouple):
			ExploredValueStr = ''
			for ParamValue in sorted(self.ExploredSingle):
				ExploredValueStr += (ParamValue[0] + '\t' + str(ParamValue[1]) + '\t' )
				ExploredValueStr += (str(self.ExploredSingle[ParamValue]) + '\n')
			for ParamValue in sorted(self.ExploredCouple):
				ExploredValueStr += (ParamValue[0][0] + '\t' + ParamValue[0][1] + '\t' )
				ExploredValueStr += (str(ParamValue[1][0]) + '\t' + str(ParamValue[1][1]) + '\t' )
				ExploredValueStr += (str(self.ExploredCouple[ParamValue]) + '\n')
			safeWrite(ExploredFileName, ExploredValueStr)
			"""
			try:	ExploredFile = open(ExploredFileName, 'w')
			except IOError:	
				# second try
				sleep(1.1)
				ExploredFile = open(ExploredFileName, 'w')
			"""
		else:
			Lines = safeRead(ExploredFileName)
##			for L in Lines:
##				SL = L.split('\t')
##				self.Explored[(SL[0],int(SL[1]))] = int(SL[2])
			# Reading explored value file
			ExploredSingle = re.findall(r"""   # e.g.: GSize  10 20 (meaning that value 10 has been tried 20 times) 
				^(\w+)\s+   # parameter name
				(-?[\d\.]+)\s+(\d+)\s*$   # one parameter value followed by count
				""",Lines, flags=re.MULTILINE|re.VERBOSE)
			ExploredCouple = re.findall(r"""   # e.g.:  GSize  MRate 10 3 16 (meaning that couple (10,3) has been tried 16 times)
				^(\w+)\s+(\w+)\s+   # parameter names
				(-?[\d\.]+)\s+(-?[\d\.]+)\s+   # sequence of two values
				(\d+)\s*$   # terminating count
				""",Lines, flags=re.MULTILINE|re.VERBOSE)

			self.ExploredSingle = {(S[0],Num(S[1])):Num(S[2]) for S in ExploredSingle}
			self.ExploredCouple = {((S[0],S[1]),(Num(S[2]),Num(S[3]))):Num(S[4]) for S in ExploredCouple}
			
			if os.path.exists(ExploredFileName) and not self.ExploredSingle and not self.ExploredCouple:
				raise Exception(f'Anomaly when reading {ExploredFileName}')

	def PreferredValue(self, Param):
		# priority is given to values that have not been properly explored
		if not self.ExploredSingle:
			return random.choice(self.Ranges[Param])
		PossibleValues = self.Ranges[Param][:]
		random.shuffle(PossibleValues)
		for v in PossibleValues:
			if (Param,v) not in self.ExploredSingle:
				return v
		CandidateValue = min(PossibleValues, key=lambda v: self.ExploredSingle[(Param, v)])
		return CandidateValue
			
	def ParamChanging(self, ChangedParam, ChangedValue=None):
		if ChangedParam is not None:
			print('changed parameter:', ChangedParam)
			if ChangedValue is None:	self.Params[ChangedParam] = self.PreferredValue(ChangedParam)
			else:	self.Params[ChangedParam] = ChangedValue
			# self.Params[ChangedParam] = random.choice(self.Ranges[ChangedParam])
			print('\tchosen value:', self.Params[ChangedParam])
			# storing new choice
			NewChoice = (ChangedParam, self.Params[ChangedParam])
			if NewChoice in self.ExploredSingle:
				self.ExploredSingle[NewChoice] += 1
			else:
				self.ExploredSingle[NewChoice] = 1
		else:
			print('No parameter changed')
		
	def PreferredCouple(self, ParamCouple):
		# priority is given to values that have not been properly explored
		(Param1, Param2) = ParamCouple
		if not self.ExploredCouple:
			return (self.PreferredValue(Param1),self.PreferredValue(Param2))
		PV1 = self.Ranges[Param1][:]
		PV2 = self.Ranges[Param2][:]
		random.shuffle(PV1)
		random.shuffle(PV2)
		for v1 in PV1:
			for v2 in PV2:
				if ((Param1,Param2),(v1,v2)) not in self.ExploredCouple:
					return (v1,v2)
		Candidates = sorted([(CoupleValues[1],self.ExploredCouple[CoupleValues])
							 for CoupleValues in self.ExploredCouple], key=lambda x: x[1])
		return Candidates[0][0]
			
	def CoupleChanging(self, Params):
		print('changed parameters: %s and %s' % Params)
		(self.Params[Params[0]],self.Params[Params[1]]) = self.PreferredCouple(Params)
		print('\tchosen values: %d and %d' % (self.Params[Params[0]],self.Params[Params[1]]))
		# storing new choice
		NewChoice = (Params, (self.Params[Params[0]],self.Params[Params[1]]))
		if NewChoice in self.ExploredCouple:
			self.ExploredCouple[NewChoice] += 1
		else:
			self.ExploredCouple[NewChoice] = 1
		
	def RandomSelect(self, OutputFile=None, verbose=True):
		""" Propagates imposed values, then chooses a parameter to change,
			and chooses a value for this parameter
		"""
		if verbose:
			print(self)
		# print 'Fixed	parameters:', ', '.join(self.NoRanges.keys())
		for ChangedParam in self.NoRanges:
			self.Params[ChangedParam] = self.NoRanges[ChangedParam]
			if verbose:
				# print 'changed parameter:', ChangedParam,
				# print '\timposed value:', self.Params[ChangedParam]
				pass

		# print 'Variable parameters:', ', '.join(self.Ranges.keys())
		if self.Multiplicative:
			if len(self.Ranges) == 2:
				self.CoupleChanging(tuple(sorted(list(self.Ranges.keys()))))
			else:
				for ChangedParam in self.Ranges:
					self.ParamChanging(ChangedParam)
		else:
			# Choosing a variable parameter to change
			# ChangedParam = random.choice([None] + list(self.Ranges.keys()))
			
			(ChangedParam, ChangedValue) = min(itertools.chain(*[[(p, v) for v in self.Ranges[p]] \
				for p in self.Ranges]), key= lambda pv: self.ExploredSingle.get(pv, 0))
			# ChangedParam = random.choice(list(self.Ranges.keys()))
			self.ParamChanging(ChangedParam, ChangedValue)

		self.relevant = set(self.Params.keys())  # all parameters are output
		if OutputFile is not None:
			self.cfg_to_txt(OutputFile)	# saving configuration (.evo) file
		else:
			print('No output generated')
		self.Params = self.Original	 # restoring original values

	def MaxReached(self, MaxNumberOfDataPointsPerConfig):
		if MaxNumberOfDataPointsPerConfig == 0:	return False
		NumberOfDataPoints = -1
		if self.ExploredSingle:
			NumberOfDataPoints = min(self.ExploredSingle.values())
		elif self.ExploredCouple:
			NumberOfDataPoints = min(self.ExploredCouple.values())
		# print('Number of data points', NumberOfDataPoints)
		return NumberOfDataPoints >= MaxNumberOfDataPointsPerConfig

	def __str__(self):
		Msg  = 'Possible %d choices are:\n\t' % self.Possibilities()
		Msg += '\n\t'.join(['\t'.join(P) for P in self.RangeParamWithStep]) + '\n\t'
		Msg += '\n\t'.join(['\t'.join(P) for P in self.ListParam]) + '\n'
		for P in self.Ranges:
			Msg += f'{P}:\t{self.Ranges[P]}\n'
		return Msg

#################################
# Loading global parameters	 #
#################################

##Evolife_Parameters = Parameters('Evolife.evo')

def safeRead(File, Waiting=None):
	if Waiting is None:
		Waiting = 1 + 2 * random.random()
	try:
		if os.path.exists(File):	# <-- can this line generate an error ?
			return open(File).read()
	except (IOError, FileNotFoundError):
		sleep(Waiting)
		try:	return open(File).read()
		except (IOError, FileNotFoundError):	pass
	if not os.path.exists(File):
		return ''
	raise IOError(f'File {File} cannot be read')
	return None
	
	
def safeWrite(File, Content, Prefix=None, Waiting=None):
	"""	Attempt to write safely into a file when several instances of the program run simultaneously
	"""

	if Prefix is None:
		Prefix = os.path.splitext(os.path.basename(sys.argv[0]))[0]
	if Waiting is None:
		Waiting = 3 + random.random() * 10
	ExploredLockFile = f'___{Prefix}_{os.getpid()}.lock'
	ExploredLockFilePattern = f'___{Prefix}_*.lock'
	# creating lock file
	open(ExploredLockFile, 'w')
	while True:
		# print(os.getpid())
		# retrieving lock files
		LockFiles = glob.glob(ExploredLockFilePattern)
		# print(LockFiles, end='\t')
		# ignoring dead lock files
		for F in LockFiles[:]:
			if time() - os.stat(F).st_mtime > Waiting:
				LockFiles.remove(F)
		# print(LockFiles)
		LockFiles.sort(key=lambda F: os.stat(F).st_mtime)	# waiting list
		try: 
			if LockFiles[0] == ExploredLockFile:
				# my turn
				open(File, 'w').write(Content)
				os.remove(ExploredLockFile)
				break
			else:
				# waiting
				print(f'Waiting {Waiting} seconds max')
				sleep(1)
		except IndexError:
			print(f"LockFile {ExploredLockFile} has disappeared")
			break	# too bad
			# safeWrite(File, Content)	# dangerous lateral recursive call
	
	# # # try:
		# # # while True:
			# # # if not os.path.exists(EXPLOREDLOCK):
				# # # lock = open(EXPLOREDLOCK, 'w')
				# # # open(File, 'w').write(Content)
				# # # lock.close()
				# # # os.remove(EXPLOREDLOCK)
				# # # break
			# # # else:
				# # # check = os.stat(EXPLOREDLOCK)
				# # # if time() - check.st_ctime > 0.1: 
					# # # os.remove(EXPLOREDLOCK)
				# # # # waiting my turn
	# # # except:
		# # # pass	# tant pis
			

if __name__ == "__main__":
	#	print __doc__ + '\n'
	MULT = False
	if len(sys.argv) > 1 and sys.argv[1] == '-m':
		MULT = True
		sys.argv.pop(1)
	if len(sys.argv) < 3 or len(sys.argv) > 5 or not sys.argv[2].endswith('.evm'):
		print('usage:')
		print('%s [-m] <stable-configuration-file> <meta-configfile> [<output-configfile>] [MaxNumberOfDataPointsPerConfig]' % os.path.basename(sys.argv[0]))
	else:	
		try:	
			Evolife_Parameters = MetaParameters(sys.argv[1], sys.argv[2], Multiplicative=MULT)
		except Exception as E:
			print('Error in reading configuration')
			print(E)
			sys.exit(1)
		# print Evolife_Parameters
		# print Evolife_Parameters.RangeParamWithStep
		# print Evolife_Parameters.ListParam
		# print(Evolife_Parameters.Ranges)
		# print(Evolife_Parameters.ExploredSingle)
		
		
		if len(sys.argv) == 3:
			Evolife_Parameters.RandomSelect(verbose = True)
		else:
			Evolife_Parameters.RandomSelect(OutputFile=sys.argv[3], verbose = False)
			# storing new choices
			Evolife_Parameters.ExploredValues(AlreadyExploredValuesFileName, Store=True)
			# try:	shutil.copy(AlreadyExploredValuesFileNameBis, AlreadyExploredValuesFileName)
			# except Exception:	pass	# tant pis

		if len(sys.argv) == 5 and sys.argv[4].isdigit():
			if Evolife_Parameters.MaxReached(int(sys.argv[4])):
				print('MAXIMUM REACHED!')
				open(STOPFILE, 'w')
				

