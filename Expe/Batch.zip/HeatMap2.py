
# after https://matplotlib.org/stable/gallery/images_contours_and_fields/pcolor_demo.html

import sys
import os
import re
import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
from itertools import product

DPI = 300	# definition of saved images

FILLMISSINGVALUES = True
BLURR = False
COLS = (2,1,4)

def translate(s):
	D = {
		'ContemptImpact':	'Impact of being outraged (h)',
		'FollowerImpact':	'Impact of being followed (s)',
		}
	if s in D:	return D[s]
	s = re.sub(r'Signal(?!l?ing)', 'Signal ', s)
	s = re.sub(r'Signall?ing', 'Signaling ', s)
	return s.replace('Policing', 'Outrage ').replace('Contempt', 'Outrage').replace('Impact', ' Impact')

def neighbours(P, MaxRadius=2):
	"""	returns neighbouring locations
	"""
	(x,y) = P
	neighbours = []
	for Radius in range(MaxRadius+1):
		for distx in range(-Radius, Radius+1):
			for disty in range(-Radius, Radius+1):
				if distx == 0 and disty == 0:	continue	# self not in neighbourhood
				Neighbour = x + distx, y + disty
				if Neighbour not in neighbours:
					neighbours.append(Neighbour)
					yield Neighbour
	
	

if __name__ == "__main__":
	FileName = sys.argv[1]
	Delimiter = ';'
	xcol, ycol, zcol = COLS

	Header = open(FileName).readlines()[0].strip().split(Delimiter)
	xtitle, ytitle, ztitle = (Header[xcol], Header[ycol], Header[zcol], )
	title = f"{xtitle} x {ytitle}"
	Signal = ztitle.lower().find('signal') >= 0

	Data = np.genfromtxt(FileName, delimiter=Delimiter, skip_header=0, usecols = (xcol, ycol, zcol), names=True)
	print(len(Data))
	print(Data[:4])
	Data = np.sort(Data)

	XYZ = dict()
	for x,y,z in Data:
		if (x,y) in XYZ:	XYZ[(abs(x),abs(y))].append(z)
		else:	XYZ[(abs(x),abs(y))] = [z]
	for Point in XYZ:	XYZ[Point] = sum(XYZ[Point])/len(XYZ[Point])
	# xyz = {(x,y):z for x,y,z in Data}

	Data = [(x,y,z) for ((x,y),z) in XYZ.items()]
	Data = zip(*Data)
	# print(tuple(Data))
	X, Y, Z = tuple(Data)
	X = np.array(X)
	Y = np.array(Y)
	Z = np.array(Z)
	# print(X)
	# XY = zip(X,Y)


	X1 = np.unique(X)
	Y1 = np.unique(Y)
	# print(X1)

	if FILLMISSINGVALUES:
		# replace missing data by closest value
		for x,y in product(X1, Y1):
			if (x,y) not in XYZ:
				nvalues = [XYZ[(x1,y1)] for x1,y1 in neighbours((x,y)) if (x1,y1) in XYZ]
				if nvalues:
					XYZ[(x,y)] = sum(nvalues)/len(nvalues)
			
	print(xtitle, X[:10], '...', len(X), 'values')
	print(ytitle, Y[:10], '...', len(Y), 'values')
	print(ztitle, Z[:10], '...', len(Z), 'values')
	
	print([XYZ.get((-30, y), None) for y in Y1])
	# XY = np.meshgrid(X1, Y1)
	# print(XY)
	# Z1 = lambda xy: 
	# print(np.meshgrid(X1, Y1, sparse=True))
	Z1 = np.array([XYZ.get((x,y), 0) for y,x in product(Y1, X1)])
	# print(Z1)
	# print(len(X1))
	# print(len(Y1))
	# print(len(Z1))
	Z1 = Z1.reshape((len(Y1),len(X1)))
	# plt.pcolormesh(X1,Y1,Z1)
	# plt.show()
	# sys.exit()
	
	if Signal:
		Z1 = Z1 * 100 / Z1.max()
		Colors = 'Blues'
		# cmap = mpl.cm.Blues(np.linspace(0,1,50))
	else:
		Colors = 'Reds'
		# cmap = mpl.cm.Reds(np.linspace(0,1,50))
	z_min, z_max = 0, np.abs(Z1).max()
	# z_min, z_max = 0, 100

	fig, ax = plt.subplots()

	print(X1)
	print(Y1)
	vmax = max(80, z_max)
	
	# cmap = mpl.colors.ListedColormap(cmap[10:,:-1])
	# cmap = mpl.colors.ListedColormap(cmap[0:,:-1])
	cmap = Colors
	
	if BLURR:
		c = ax.pcolormesh(X1, Y1, Z1, cmap=cmap, shading='gouraud', vmin=z_min, vmax=vmax)
	else:
		c = ax.pcolormesh(X1, Y1, Z1, cmap=cmap, shading='auto', vmin=z_min, vmax=vmax)
	# c = ax.pcolormesh(X1, Y1, Z1)
	ax.set_title(translate(ztitle))
	ax.set_xlabel(translate(xtitle))
	ax.set_ylabel(translate(ytitle))
	# set the limits of the plot to the limits of the data
	ax.axis([X.min(), X.max(), Y.min(), Y.max()])
	fig.colorbar(c, ax=ax)

	
	ImageName = f'_{xtitle}_x_{ytitle}__{ztitle}.png'.replace(' ', '')
	plt.show()
	fig.savefig(ImageName, dpi=DPI)
	print(ImageName, 'created')

